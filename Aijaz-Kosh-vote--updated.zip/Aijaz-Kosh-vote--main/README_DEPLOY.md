# KoSh Vote — Deployment (Auto SMM Panel Dispatch build)

## What's new in this build
- **Auto SMM Panel dispatch**: When a user places an order for a service that has a mapped Panel Service ID, the server automatically forwards it to your SMM Panel API and stores the returned upstream order id. Status becomes `Processing`.
- **Admin-only API config**: Only admin can set Panel API URL + API Key from Admin → System Settings → "SMM Panel API".
- **Admin-only prices**: Categories, service names, prices, min/max qty and Panel Service ID are all editable per service (Admin → Services).
- **Block / unblock users**: Admin → Users (block toggle). Blocked users cannot log in or use API.
- **Password reset for all users**: `/api/auth/forgot-password` (mobile-based reset flow already wired in the Login screen).
- **Sync from Panel** button (Admin → Orders): polls the SMM panel for status of all currently `Processing` orders and updates Completed / Cancelled / Partial.
- **Manual fallback**: If a service has no `upstream_service_id`, order stays `Pending` and admin can Complete or Cancel & Refund manually.
- **New-order notification badge**: pulsing badge on Orders tab when a new pending order arrives.

## Environment
- Node 18+
- `JWT_SECRET` — set to a long random string in production.
- Data file: `data.db` in project root (SQLite via better-sqlite3-compatible layer). Persist this file on your host.

## Install & run
```bash
npm install
npm run dev          # dev (Vite + Express in one process)
# or
npm run build && npm start   # production
```

## Configure the SMM Panel
1. Log in as admin (default `admin / admin123` — change immediately).
2. Go to **Admin → System Settings → SMM Panel API**.
3. Paste your Panel URL (e.g. `https://yourpanel.com/api/v2`) and your API Key. Save.
4. Go to **Admin → Services**, edit each service and paste its **Panel Service ID** (numeric id from your SMM panel). Empty = manual only.

Every new user order for a mapped service is now auto-sent to your panel.

## Hosting (Node)
Works on any Node host (Railway, Render, Fly.io, VPS). Deploy the whole folder, run `npm install && npm run build && npm start`. Expose port `PORT` (default 3000).
